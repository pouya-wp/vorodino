<?php
/**
 * Elementor Widgets for Advanced Login Plugin
 * ویجت‌های Elementor برای پلاگین ورود پیشرفته
 */

if (!defined('ABSPATH')) {
    exit;
}
// این فایل فقط برای سازگاری یا کدهای غیر ویجت استفاده شود. تمام کلاس‌های ویجت به پوشه widgets منتقل شده‌اند.
// اگر کد خاصی غیر از ویجت‌ها نیاز است، اینجا قرار دهید.

?>